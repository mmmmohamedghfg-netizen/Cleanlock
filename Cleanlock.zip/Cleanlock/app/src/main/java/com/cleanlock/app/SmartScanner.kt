package com.cleanlock.app

import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.StatFs
import java.io.File

data class Junk(
    val file: File,
    val category: String,
    val score: Int,      // AI confidence 0..100 that this file is useless
    val reason: String,
) { val size: Long get() = file.length() }

/**
 * "AI" cleaner: on-device scoring model. Each file gets features
 * (extension, hidden, folder type, age, size, trash marker) weighted into a
 * confidence score. Only files above the threshold are proposed.
 * User media/documents are protected unless they are in trash.
 */
object SmartScanner {
    private val junkExt = setOf("tmp", "temp", "log", "bak", "old", "dmp", "chk",
        "crdownload", "part", "thumb", "cache", "thumbdata")
    private val junkDirs = setOf(".thumbnails", "thumbnails", ".cache", "cache", ".trash",
        ".trashed", "trash", "lost.dir", ".recycle", "recyclebin", ".tmp", "temp", "tmp",
        "logs", "log", ".um", ".spotlight", ".dthumb")
    private val protectedExt = setOf("jpg", "jpeg", "png", "gif", "webp", "heic", "mp4", "mkv",
        "mov", "3gp", "mp3", "m4a", "wav", "flac", "pdf", "doc", "docx", "xls", "xlsx",
        "ppt", "pptx", "txt", "zip", "rar", "7z", "vcf", "opus", "aac")
    const val THRESHOLD = 60

    fun root(): File = Environment.getExternalStorageDirectory()

    fun hasAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ctx.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED

    fun score(f: File, root: File, now: Long): Junk? {
        val name = f.name.lowercase()
        val ext = f.extension.lowercase()
        var s = 0
        val why = mutableListOf<String>()
        var cat = "Other"

        val trashed = name.startsWith(".trashed-")
        if (trashed) { s += 90; why += "Deleted item in trash"; cat = "Trash" }

        val inJunkDir = generateSequence(f.parentFile) { it.parentFile }
            .takeWhile { it.path.length > root.path.length }
            .any { it.name.lowercase() in junkDirs }
        if (inJunkDir) { s += 45; why += "Inside cache/trash folder"; if (cat == "Other") cat = "Cache" }

        if (ext in junkExt) { s += 50; why += "Temp/log file"; if (cat == "Other") cat = "Temp" }
        if (f.length() == 0L) { s += 35; why += "Empty file"; if (cat == "Other") cat = "Empty" }

        val ageDays = (now - f.lastModified()) / 86_400_000L
        if (ext == "apk" && ageDays > 14) { s += 65; why += "Old installer"; cat = "APK" }
        if (ageDays > 30) s += 10
        if (ageDays > 180) s += 10
        if (name.startsWith(".") && s > 0) { s += 10; why += "Hidden" }
        if (f.length() > 50L * 1024 * 1024 && s > 0) s += 5

        if (ext in protectedExt && !trashed && !inJunkDir) return null
        if (s < THRESHOLD) return null
        return Junk(f, cat, s.coerceAtMost(99), why.joinToString(" • "))
    }

    fun scan(onProgress: (Int) -> Unit = {}): List<Junk> {
        val root = root()
        val androidDir = File(root, "Android").path
        val now = System.currentTimeMillis()
        val out = ArrayList<Junk>()
        var seen = 0
        root.walkTopDown()
            .onEnter { it.path != androidDir }
            .filter { it.isFile }
            .forEach { f ->
                seen++
                if (seen % 500 == 0) onProgress(seen)
                runCatching { score(f, root, now) }.getOrNull()?.let(out::add)
            }
        return out.sortedByDescending { it.size }
    }

    fun clearOwnCache(ctx: Context): Long {
        var freed = 0L
        listOfNotNull(ctx.cacheDir, ctx.externalCacheDir).forEach { dir ->
            dir.walkBottomUp().forEach { f ->
                if (f != dir) { if (f.isFile) freed += f.length(); f.delete() }
            }
        }
        return freed
    }

    fun delete(items: List<Junk>): Long {
        var freed = 0L
        items.forEach { j ->
            val len = j.size
            if (runCatching { j.file.delete() }.getOrDefault(false)) freed += len
        }
        return freed
    }

    fun storage(): Pair<Long, Long> {
        val s = StatFs(Environment.getDataDirectory().path)
        return (s.totalBytes - s.availableBytes) to s.totalBytes
    }
}
