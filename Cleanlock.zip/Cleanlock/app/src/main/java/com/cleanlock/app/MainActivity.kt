package com.cleanlock.app

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.format.Formatter
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Accent = Color(0xFF1DE9B6)
private val CardBg = Color(0xFF16213A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Color(0xFF0B1220), surface = CardBg)) {
                Surface(Modifier.fillMaxSize(), color = Color(0xFF0B1220)) { CleanerScreen() }
            }
        }
    }
}

@Composable
fun CleanerScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var hasPerm by remember { mutableStateOf(SmartScanner.hasAccess(ctx)) }
    var items by remember { mutableStateOf(listOf<Junk>()) }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Tap scan to find junk files") }
    var storage by remember { mutableStateOf(SmartScanner.storage()) }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) { hasPerm = SmartScanner.hasAccess(ctx); storage = SmartScanner.storage() }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val legacy = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        hasPerm = SmartScanner.hasAccess(ctx)
    }

    fun askPermission() {
        if (Build.VERSION.SDK_INT >= 30) {
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                Uri.parse("package:${ctx.packageName}")))
        } else legacy.launch(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
    }

    val selectedItems = items.filter { it.file.path in selected }
    val selectedSize = selectedItems.sumOf { it.size }
    val used = storage.first
    val total = storage.second

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(16.dp)) {
        Text("Cleanlock", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Accent)
        Text("AI Phone Cleaner", color = Color.Gray)
        Spacer(Modifier.height(16.dp))

        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(CardBg).padding(16.dp)) {
            Text("Storage: ${Formatter.formatFileSize(ctx, used)} / ${Formatter.formatFileSize(ctx, total)}")
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { used.toFloat() / total }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Text(status, color = Color.LightGray, fontSize = 13.sp)
        }
        Spacer(Modifier.height(12.dp))

        if (!hasPerm) {
            Button(onClick = { askPermission() }, modifier = Modifier.fillMaxWidth()) { Text("Grant file access") }
        } else {
            Button(
                enabled = !busy,
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    busy = true; status = "AI is scanning..."
                    scope.launch {
                        val res = withContext(Dispatchers.IO) { SmartScanner.scan { } }
                        items = res
                        selected = res.filter { it.score >= 75 }.map { it.file.path }.toSet()
                        status = "Found ${res.size} junk files (${Formatter.formatFileSize(ctx, res.sumOf { it.size })})"
                        busy = false
                    }
                }
            ) { Text(if (busy) "Scanning..." else "Smart AI Scan") }
        }

        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(items.take(500), key = { it.file.path }) { j ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(14.dp)).background(CardBg).padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = j.file.path in selected, onCheckedChange = {
                        selected = if (it) selected + j.file.path else selected - j.file.path
                    })
                    Column(Modifier.weight(1f)) {
                        Text(j.file.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                        Text("${j.category} • ${j.reason}", fontSize = 11.sp, color = Color.Gray, maxLines = 2)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(Formatter.formatShortFileSize(ctx, j.size), fontSize = 12.sp)
                        Text("AI ${j.score}%", fontSize = 11.sp, color = Accent)
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Button(
            enabled = !busy && hasPerm,
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                busy = true; status = "Cleaning..."
                scope.launch {
                    val freed = withContext(Dispatchers.IO) {
                        SmartScanner.delete(selectedItems) + SmartScanner.clearOwnCache(ctx)
                    }
                    items = items.filter { it.file.exists() }
                    selected = selected.filter { p -> items.any { it.file.path == p } }.toSet()
                    storage = SmartScanner.storage()
                    status = "Freed ${Formatter.formatFileSize(ctx, freed)}"
                    busy = false
                }
            }
        ) { Text("Clean ${selectedItems.size} files (${Formatter.formatShortFileSize(ctx, selectedSize)})") }

        OutlinedButton(
            modifier = Modifier.fillMaxWidth(),
            onClick = { ctx.startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)) }
        ) { Text("Other apps' cache (system settings)") }
    }
}
