# Cleanlock - AI phone cleaner. Push -> Actions -> Build APK -> download artifact.
